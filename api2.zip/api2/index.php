<html>
    <body>
        <form action="api/read.php" method="get">
            From Currency: <input type="text" name="fromcurr" value="eur" /><br/>
            To Currency: <input type="text" name="tocurr"/><br>
            Amount: <input type="number" name="amount" step="any"/><br>
            <input type="submit" value="Convert"/>
        </form>
    </body>
</html>
